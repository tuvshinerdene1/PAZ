
import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;

import java.lang.*;

public class exercise3 extends ConsoleProgram{
	
	public void run(){
		String str = readLine("Enter the word: ");
		println(capitalize(str));
	}
	String capitalize(String str){
		String result = str.substring(0,1).toUpperCase() + str.substring(1).toLowerCase();
		return result;
	}
	
	public static void main(String[] arg){
		new exercise3().start();
	}
}
