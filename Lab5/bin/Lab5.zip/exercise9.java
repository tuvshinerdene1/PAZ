import acm.graphics.GLine;
import acm.program.*;

public class exercise9 extends GraphicsProgram {
	public static final int BOARD_SIZE = 300;
	
	public void run(){
		double windowW=getWidth();
		double windowH=getHeight();
		GLine v1 = new GLine((windowW-BOARD_SIZE)/2+BOARD_SIZE/3, (windowH-BOARD_SIZE)/2, (windowW-BOARD_SIZE)/2+BOARD_SIZE/3,(windowH-BOARD_SIZE)/2+BOARD_SIZE);
		add(v1);
		GLine v2 = new GLine((windowW-BOARD_SIZE)/2+(BOARD_SIZE/3)*2, (windowH-BOARD_SIZE)/2, (windowW-BOARD_SIZE)/2+(BOARD_SIZE/3)*2,(windowH-BOARD_SIZE)/2+BOARD_SIZE);
		add(v2);
		
		GLine h2 = new GLine((windowW - BOARD_SIZE)/2, (windowH-BOARD_SIZE)/2+(BOARD_SIZE/3)*2 ,(windowW - BOARD_SIZE)/2+BOARD_SIZE,(windowH-BOARD_SIZE)/2+(BOARD_SIZE/3)*2);
		add(h2);
		GLine h1 = new GLine((windowW - BOARD_SIZE)/2, (windowH-BOARD_SIZE)/2+(BOARD_SIZE/3) ,(windowW - BOARD_SIZE)/2+BOARD_SIZE,(windowH-BOARD_SIZE)/2+(BOARD_SIZE/3));
		add(h1);
	}
	
	public static void main(String[] args){
		new exercise9().start();
	}
}
