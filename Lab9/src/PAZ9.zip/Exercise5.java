import acm.program.ConsoleProgram;
import java.lang.*;

public class Exercise5 extends ConsoleProgram{
	
	private int a, b;
	
	public void run(){
		println("This programm will use swap method!!!");
		a = readInt("Enter a= ");
		b = readInt("Enter b= ");
		swap(a, b);
		println("After swapping:");
		println("a is now "+a);
		println("b is now "+b);
	}
	
	private void swap(int x, int y){
		this.a = y;
		this.b = x;
	}
	
	public static void main(String[] arg){
		new Exercise5().start();
	}
}
